package com.eazybytes.message;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MessageApplicationTests {

	@Test
	void contextLoads() {
	}

}
